var colCount = 0;
var colWidth = 350;
var margin = 30;
var spaceLeft = 0;
var windowWidth = 0;
var blocks = []; 
var removebio = true;
var hidegroupone=true;
var hidegrouptwo=true;
var hidegroupthree=true;
var bottomofpage=0;
var firstload=1;


/*document.addEventListener('scroll', function (event) {
    if (document.body.scrollHeight == 
        document.body.scrollTop +        
        window.innerHeight) {       
        document.getElementById("bottombar").style.opacity='1';
	document.getElementById("bottombar").style.filter='alpha(opacity=100);'; 
    }
});*/


$(function () {
    $(window).resize(setupBlocks);
    $(window).resize(placebottombar);
});

function onLinkedInLoad() {
  IN.Event.on(
    IN
    , "auth"
    , function() {
      Instant().onAuth();
    }
  );
};

function logout(){
	$("body").css("cursor", "progress");
        $('.topbutton').css("cursor", "progress");
        $('a').css("cursor", "progress");
	IN.User.logout(onLinkedInLogout);
}

function onLinkedInLogout(){
	$("body").css("cursor", "progress");
        $('.topbutton').css("cursor", "progress");
        $('a').css("cursor", "progress");
	window.location='login.php';
	$.get("logout.php");
    	return false;
}

function nonLinkedInLogout(){
	$("body").css("cursor", "progress");
        $('.topbutton').css("cursor", "progress");
        $('a').css("cursor", "progress");
	window.location='logout.php';
    	return false;
}

function showloginalert(){
	swal("Oops...", "Please login to add your card", "error");
}

function showloginalertevent(){
	swal("Oops...", "Please login to create an event", "error");
}


$(function () {




	var useremail = document.getElementById("useremail").innerHTML;
	//var event = document.getElementById("eventtag").innerHTML;
	var event_id = document.getElementById("eventid").innerHTML;
	var nmemberid = document.getElementById("nmemberid").innerHTML;
	var lmemberid = document.getElementById("lmemberid").innerHTML;
        var dataString = 'eventid1=' + event_id + '&nmemberid1=' + nmemberid + '&lmemberid1=' + lmemberid;
        if (useremail != '' ) {
		// AJAX code to submit form.
		$.ajax({
		type: "POST",
		url: "query/checkcardquery.php",
		data: dataString,
		cache: false,
		success: function(result) {
		if(result>0){
			var editurl="edit_card.php?event_id="+event_id;
			document.getElementById("addcardbutton").innerHTML = 'Edit Card';
			document.getElementById("addcardbutton").setAttribute('onclick',"window.location.href='"+editurl+"'");
		}
		else{
			var createurl="create_card.php?event_id="+event_id;
			document.getElementById("addcardbutton").innerHTML = '<a href="#" style="color:black;text-decoration:none;vertical-align:middle;">Add Card</a></td>';
			document.getElementById("addcardbutton").setAttribute('onclick',"window.location.href='"+createurl+"'");
		}
			},
		error: function (request, status, error) {
		        //alert(request.responseText);
		    }
		});
	}
	
	
	
	if(document.getElementById("page").innerHTML=="myevents"){
		document.getElementById("bottombar").style.display='none';
		fillmyEventsCards();	
		if(event_id==''){document.getElementById("backbutton").style.display='none';}
		
		
		document.getElementById("top-menu").style.opacity='1';
		document.getElementById("top-menu").style.filter='alpha(opacity=100);';

	}
	else{	
		
		//var event = document.getElementById("eventtag").innerHTML;
		var eventidurl = document.getElementById("eventid").innerHTML;
		var dataString = 'eventid=' + eventidurl;
		//var dataString = 'eventid=' + eventidurl;
		// AJAX code to submit form.
		$.ajax({
		type: "POST",
		url: "query/checkeventquery.php",
		data: dataString,
		cache: false,
		success: function(result) {
		var resultarray = result.split(",");
		var eventid=resultarray[0];
		var eventname=resultarray[1];
		var eventdate=resultarray[2];
		var groupno=resultarray[3];
		var group1name=resultarray[4];
		var group2name=resultarray[5];
		var group3name=resultarray[6];
		var width=0;
		if((eventidurl!=eventid || eventidurl=='' || result==',,,,,,') && (useremail!='') ){
			window.location='http://www.cardstak.com/cards/index.php?&page=myevents';
			}
		else if((eventidurl!=eventid || eventidurl=='' || result==',,,,,,') && (useremail=='') ){
			window.location='http://www.cardstak.com/cards/login.php';
			}
		else{
			if(groupno==3){
				document.getElementById("g1button").innerHTML = group1name;
				document.getElementById("g2button").innerHTML = group2name;
				document.getElementById("g3button").innerHTML = group3name;
				width = document.getElementById("g1buttonback").clientWidth + document.getElementById("g2buttonback").clientWidth + document.getElementById("g3buttonback").clientWidth + document.getElementById("showallbutton").clientWidth+5;
			}
			if(groupno==2){
				document.getElementById("g1button").innerHTML = group1name;
				document.getElementById("g2button").innerHTML = group2name;
				document.getElementById("g3buttonback").style.display = 'none';
				width = document.getElementById("g1buttonback").clientWidth + document.getElementById("g2buttonback").clientWidth + document.getElementById("showallbutton").offsetWidth+2;
			}
			if(groupno==1){
				document.getElementById("g1buttonback").style.display = 'none';
				document.getElementById("g2buttonback").style.display = 'none';
				document.getElementById("g3buttonback").style.display = 'none';
				document.getElementById("showallbutton").style.display = 'none';
				document.getElementById("rolestext").style.display='none';
			}
		
		}
		document.getElementById("eventtag").innerHTML = eventname;
		document.getElementById("event").innerHTML = eventname;
		document.title = eventname;
		document.getElementById("leftbr").style.width=width+'px';
		document.getElementById("rolestext").style.paddingLeft=((width-143)/2)+'px';
		document.getElementById("wizardtext").style.width = (width+136)+'px';
		if(eventdate!='' && eventdate!=' '){	
		document.getElementById("event").innerHTML="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+eventname+"<span id=\"spandate\" style=\"font-size: 14pt;color:#6BAEA6;\">&nbsp;&nbsp;("+eventdate+")</span>";
		}	
		document.getElementById("top-menu").style.opacity='1';
		document.getElementById("top-menu").style.filter='alpha(opacity=100);';
		document.getElementById("sharebtn").style.opacity='1';
		document.getElementById("sharebtn").style.filter='alpha(opacity=100);'; 
		if (useremail == '' ) {$('#wizardbackground, #wizard').fadeIn(350);}
		//document.getElementById("wizardbackground").style.opacity='0.8';
		//document.getElementById("wizardbackground").style.filter='alpha(opacity=80);';
		//document.getElementById("wizard").style.opacity='1';
		//document.getElementById("wizard").style.filter='alpha(opacity=100);';
		},
		error: function (request, status, error) {
		        //alert(request.responseText);
		}
		});
		
		
		
		
		document.getElementById("bottombar").style.display='';
		document.getElementById("page").innerHTML="";
		if(nmemberid==''){nmemberid="Not Available";}
		if(lmemberid==''){lmemberid="Not Available";}

	        var dataString = 'eventid=' + event_id + '&lmemberid=' + lmemberid + '&nmemberid=' + nmemberid  + '&event=' + event ;
	        
	        //alert(useremail=='');
	        if (useremail == '' ) {
			//alert("Please login to build your Cardstak");
			//swal("Oops...", "Please login to build your Cardstak", "error");
			document.getElementById("myeventsbutton").style.display='none';
			document.getElementById("createbuttontop").innerHTML="<a href=\"#\" class=\"topmenulink\" onclick=\"showloginalertevent();\">Create Event</a>";
		} 
		
		
		document.getElementById("mainbody").innerHTML='<div style="width: 100%;position: fixed;top: 300px;padding-left: auto;" ><IMG SRC="images/loader3.gif" class="loader"></div>';
		// AJAX code to submit form.
		$.ajax({
		type: "POST",
		url: "query/fillcards.php",
		data: dataString,
		cache: false,
		success: function(html) {
		document.getElementById("mainbody").innerHTML=html;
		
		setupBlocks();
		
		
		$('.block').each(function (i) {
			$(this).css({
				'-webkit-transition': 'all .6s ease-out',
				'-moz-transition': 'all .6s ease-out',
				'-o-transition': 'all .6s ease-out',
				'transition': 'all .6s ease-out',  'opacity': '1', 'filter': 'alpha(opacity=100)'
				});
		});
		
		$('.dont_open').click(function(e){ e.stopPropagation(); });

	      $(".bio").dotdotdot();
	      
	   	placebottombar();  
	      
		},
		error: function (request, status, error) {
		        //alert(request.responseText);
		    }
		});
		
	
	
	
	}
		

});


function placebottombar(){
	//document.getElementById("bottombar").style.opacity='0';
	//document.getElementById("bottombar").style.filter='alpha(opacity=0);'; 
	bottomofpage=Math.max(Math.max.apply(null,blocks),($(window).height()-44));
	document.getElementById("bottombar").style.top=bottomofpage+ 'px';
	document.getElementById("bottombar").style.opacity='1';
	document.getElementById("bottombar").style.filter='alpha(opacity=100);'; 
		      
}


function gotoEditCard(){
	$("body").css("cursor", "progress");
        $('.topbutton').css("cursor", "progress");
        $('a').css("cursor", "progress");
	//var event = document.getElementById("eventtag").innerHTML;
	var event_id = document.getElementById("eventid").innerHTML;
	var edit_url="edit_card.php?"+"event_id="+event_id;
	window.location=edit_url;	
}


function setupBlocks() {
    windowWidth = $(window).width();
    windowheight = $(window).height();
    blocks = [];
    if(	windowWidth <500) {
    	colWidth=windowWidth*0.9; 
    	margin=windowWidth*0.05;
    	colCount = Math.floor(windowWidth / (colWidth + margin * 2));
    	for (var i = 0; i < colCount; i++) {
        blocks.push(margin + windowheight*0.3);
    	}
    }
    else {
    	colWidth=350;
    	margin=35;
    	colCount = Math.floor(windowWidth / (colWidth + margin * 2));
    	for (var i = 0; i < colCount; i++) {
        blocks.push(margin + 95);
    	}	
    }
    // Calculate the margin so the blocks are evenly spaced within the window
    
    spaceLeft = (windowWidth - ((colWidth * colCount) + (margin * (colCount - 1)))) / 2;
    console.log(spaceLeft);
    
    

    positionBlocks();
}

function positionBlocks() {
	if(windowWidth <500) {
	    	$('.block').each(function (i) {
	        var min = Array.min(blocks);
	        var index = $.inArray(min, blocks);
	        var leftPos = (index * (colWidth + margin));
	        $(this).css({
	            'left': (leftPos + spaceLeft) + 'px',
	                'top': min + 'px', 'width': colWidth + 'px'
	        		});
	        blocks[index] = min + $(this).outerHeight() + margin;
	   	 }); 
	   	 
	   	$('#commentbox').css({
	            'left': '0px',
	                'width': '100%'
	        	});
	   	
	   	$('.topcard').each(function (i) {
	        $(this).css({
	            'width': colWidth + 'px'
	        		});
	   	 }); 
	   	document.getElementById("sharebtn").style.display='none';
	   	 document.getElementById("wizardbackground").style.display='none';
		document.getElementById("wizard").style.display='none';
	   	 $('.bio').each(function (i) {
	        $(this).css({
	            'width': (colWidth-26) + 'px'
	        		});
	   	 }); 
	   	 
	   	 $('.topbutton').each(function (i) {
	        $(this).css({
	            'font-size': '3vw'
	        		});
	   	 }); 
	   	 
	   	 $('.bottombar').each(function (i) {
	        $(this).css({
	            'font-size': '5vw'
	        		});
	   	 }); 
	   	 
	   	 $('.contactinfo').each(function (i) {
	        $(this).css({
	            'width': (0.7*windowWidth)+'px'
	        		});
	   	 });
	   	 
	   	 $('.cardname').each(function (i) {
	        $(this).css({
	            'font-size': '6.5vw'
	        		});
	   	 });
	   	 
	   	 $('.cardtitle').each(function (i) {
	        $(this).css({
	            'font-size': '5.5vw'
	        		});
	   	 });
	   	 
	   	 document.getElementById("createbuttontop").style.display='none';
	   	 document.getElementById("cardstakbuttontop").style.display='none';
		 //document.getElementById("sharebuttontop").style.display='none';   
		 document.getElementById("event").style.fontSize	="6vw";	
		 document.getElementById("g1buttonback").style.fontSize="3vw";
		 document.getElementById("g2buttonback").style.fontSize="3vw";
		 document.getElementById("g3buttonback").style.fontSize="3vw";
		 document.getElementById("g1buttonback").style.minWidth="0px";
		 document.getElementById("g2buttonback").style.minWidth="0px";
		 document.getElementById("g3buttonback").style.minWidth="0px";
		 firstload=0;
		 //document.getElementById("displaybuttonback").style.fontSize="3vw";
		 //document.getElementById("spandate").style.fontSize="4vw";
    	
	}
	else {
		   
	    	$('.block').each(function (i) {
	        var min = Array.min(blocks);
	        var index = $.inArray(min, blocks);
	        var leftPos = (index * (colWidth + margin));
	        $(this).css({
	            'left': (leftPos + spaceLeft) + 'px',
	                'top': min + 'px', 'width': '350px'
	        });
	        blocks[index] = min + $(this).outerHeight() + margin;
	   	 }); 

	   	if (firstload!=1){ 
	   	 
		   	$('#commentbox').css({
		            'left': '31%',
		                'width': '36%%'
		        	}); 
		   	 
		   	 
		   	$('.topcard').each(function (i) {
		        $(this).css({
		            'width': '350px'
		        		});
		   	 });  
		   	 
		   	 $('.bio').each(function (i) {
		        $(this).css({
		            'width': '324px'
		        		});
		   	 });  
		   	 
		   	 $('.topbutton').each(function (i) {
		        $(this).css({
		            'font-size': '12.5pt'
		        		});
		   	 });
		   	 
		   	  $('.bottombar').each(function (i) {
		        $(this).css({
		            'font-size': '16pt'
		        		});
		   	 });
		   	 
		   	 $('.contactinfo').each(function (i) {
		        $(this).css({
		            'width': '292px'
		        		});
		   	 }); 
		   	 
		   	 $('.cardname').each(function (i) {
		        $(this).css({
		            'font-size': '20pt'
		        		});
		   	 });
		   	 
		   	 $('.cardtitle').each(function (i) {
		        $(this).css({
		            'font-size': '16pt'
		        		});
		   	 });
		   	 document.getElementById("sharebtn").style.display='';
		   	 document.getElementById("createbuttontop").style.display='';
		   	 document.getElementById("cardstakbuttontop").style.display='';
			 //document.getElementById("sharebuttontop").style.display=''; 
			 document.getElementById("event").style.fontSize="19pt";
			 document.getElementById("g1buttonback").style.fontSize="12.5pt";
			 document.getElementById("g2buttonback").style.fontSize="12.5pt";
			 document.getElementById("g3buttonback").style.fontSize="12.5pt";
			 document.getElementById("g1buttonback").style.minWidth="70px";
			 document.getElementById("g2buttonback").style.minWidth="70px";
			 document.getElementById("g3buttonback").style.minWidth="70px";
			 firstload=0;
		}
        }
	
  
}


// Function to get the Min value in Array
Array.min = function (array) {
    return Math.min.apply(Math, array);
};


function openPhone(hostDivName) {
    $('#phonebackground, #phonebox').fadeIn(350);
    var hostDiv = document.getElementById(hostDivName);
    var theElements = hostDiv.getElementsByClassName("cardphone");
    var cardPhone = theElements[0].innerHTML;
    document.getElementById("phoneboxnumber").innerHTML = cardPhone;

}

function closePhone() {
    $('#phonebackground, #phonebox').fadeOut(350);

}


function addComment(hostDivName) {
	
        $('#commentbackground, #commentbox').fadeIn(350);
        var hostDiv = document.getElementById(hostDivName);
        var cardRole = hostDiv.parentNode.className;
        var cardName = (hostDiv.getElementsByClassName("cardname"))[0].innerHTML;
        var cardTitle = (hostDiv.getElementsByClassName("cardtitle"))[0].innerHTML;
        var cardPicture = (hostDiv.getElementsByClassName("picture"))[0].innerHTML;
        var cardid = (hostDiv.getElementsByClassName("cardid"))[0].innerHTML; 
        var cardcomment = (hostDiv.getElementsByClassName("commentoncard"))[0].innerHTML;
        var cardsaved = (hostDiv.getElementsByClassName("save"))[0].innerHTML;
        var cardEvent = (hostDiv.getElementsByClassName("cardevent"))[0].innerHTML;
        cardPicture = cardPicture.replace("class=\"circle\"", "class=\"commentpicture\"");
        //alert(firstName);
        if (cardEvent=="") {cardEvent=document.getElementById("eventtag").innerHTML;}
        document.getElementById("commentnoteid").innerHTML = "saving <b>" + cardName + "</b>'s card<br><b>" + cardTitle + "</b>";
        document.getElementById("commentpicture").innerHTML = cardPicture;
        document.getElementById("commentcardid").innerHTML = cardid;
        document.getElementById("commentcardname").innerHTML = hostDivName;
        document.getElementById("commentspace").value=cardcomment.replace(/&amp;/g, "&");
        document.getElementById("commentcardevent").innerHTML = "<b>Event: </b>"+cardEvent+"";
	if(document.getElementById("displaying").innerHTML == 'savedcards'){
		document.getElementById("commentcardrole").innerHTML =  "<b>Role: </b>"+(hostDiv.getElementsByClassName("cardrole"))[0].innerHTML;
		
        }
        else{
	if (cardRole=="1") {  document.getElementById("commentcardrole").innerHTML = "<b>Role: </b>"+document.getElementById("g1button").innerHTML;}
	if (cardRole=="2") {  document.getElementById("commentcardrole").innerHTML = "<b>Role: </b>"+document.getElementById("g2button").innerHTML;}
	if (cardRole=="3") {  document.getElementById("commentcardrole").innerHTML = "<b>Role: </b>"+document.getElementById("g3button").innerHTML;}
		
        }

        if (cardsaved=="save"){
        	document.getElementById("commentcardsaved").innerHTML ="not saved";
        	document.getElementById("savecardbutton").value="save";
        	document.getElementById("deletecardbutton").style.display = 'none';
        }
        else{
        	document.getElementById("commentcardsaved").innerHTML ="edit"; 
        	document.getElementById("savecardbutton").value="update";
        	document.getElementById("deletecardbutton").style.display = '';
        }	
        
        //alert(document.getElementById("commentcardsaved").innerHTML);
        
    

}



function openEmail(hostDivName,email) {
        $('#contactbackground, #contact').fadeIn(350);
        var hostDiv = document.getElementById(hostDivName);
        var cardName = (hostDiv.getElementsByClassName("cardname"))[0].innerHTML;
        var cardPicture = (hostDiv.getElementsByClassName("picture"))[0].innerHTML;
        var cardEvent = (hostDiv.getElementsByClassName("cardevent"))[0].innerHTML;
        cardPicture = cardPicture.replace("class=\"circle\"", "class=\"commentpicture\"");

	if(document.getElementById("displaying").innerHTML == 'savedcards'){
		cardEvent="Follow Up";
	}

        
        if (cardEvent=="") {cardEvent=document.getElementById("eventtag").innerHTML;}
        document.getElementById("contactpicture").innerHTML = cardPicture;
        document.getElementById("contactname").innerHTML = cardName;
        document.getElementById("contactemailfrom").value =document.getElementById("useremail").innerHTML;
        document.getElementById("contactemailto").value = email;
        document.getElementById("contactsubject").value = cardEvent;
        document.getElementById("contactmessage").focus();
        var gmailaddress="https://mail.google.com/mail/?view=cm&amp;fs=1&to="+email+"&su="+cardEvent;
        var yahooaddress="http://compose.mail.yahoo.com/?to="+email+"&subject="+cardEvent;
        //alert(gmailaddress);
        document.getElementById("gmailcontact").setAttribute('href', gmailaddress);
        document.getElementById("yahoocontact").setAttribute('href', yahooaddress);
	
}

function sendEmail() {
	whitenContact();
	var Emailfrom=document.getElementById("contactemailfrom").value;
	var Emailto=document.getElementById("contactemailto").value;
	var Emailsubject=document.getElementById("contactsubject").value;
	var Emailmessage=document.getElementById("contactmessage").value;
	var Toname=document.getElementById("contactname").innerHTML;
	var Fromname=document.getElementById("userfullname").innerHTML;
        if(validateEmail(Emailfrom)==false){
        	sweetAlert("Oops...", "Please add your Email address", "error");
		document.getElementById("contactemailfrom").style.border="1px solid red";
		document.getElementById("contactemailfrom").style.background="rgb(255, 238, 238)";
        }
        else if(validateEmail(Emailto)==false){
        	sweetAlert("Oops...", "Please add a valid Email address to send to", "error");
		document.getElementById("contactemailto").style.border="1px solid red";
		document.getElementById("contactemailto").style.background="rgb(255, 238, 238)";
        }
        else if(Emailsubject==""){
        	sweetAlert("Oops...", "Please add an Email subject", "error");
		document.getElementById("contactsubject").style.border="1px solid red";
		document.getElementById("contactsubject").style.background="rgb(255, 238, 238)";
        }
        else if(Emailmessage==""){
        	sweetAlert("Oops...", "Please add an Email message", "error");
		document.getElementById("contactmessage").style.border="1px solid red";
		document.getElementById("contactmessage").style.background="rgb(255, 238, 238)";
        }
         else if(Emailto=="test@test.com"){
        	sweetAlert("Oops...", "This is a sample card not a real one", "error");
		document.getElementById("contactemailto").style.border="1px solid red";
		document.getElementById("contactemailto").style.background="rgb(255, 238, 238)";
        }
        else{
        	$("body").css("cursor", "progress");
      		$(":button").css("cursor", "progress");
		
        	 var dataString = 'emailfrom=' + Emailfrom + '&emailto=' + Emailto + '&emailsubject=' + Emailsubject + '&emailmessage=' + Emailmessage + '&fromname=' + Fromname + '&toname=' + Toname;
        	
        	$.ajax({
		type: "POST",
		url: "query/emailquery.php",
		data: dataString,
		cache: false,
		success: function(html) {
		//alert(html);
		swal({   title: "Email Sent",    timer: 1000 });
		document.getElementById("contactmessage").value="";
		closeContact();
		$("body").css("cursor", "default");
		$(":button").css("cursor", "pointer");
			},
		error: function (request, status, error) {
		document.getElementById("contactmessage").value="";
		$("body").css("cursor", "default");
		$(":button").css("cursor", "pointer");
		    }
		});
        
        }
        
	
}

function whitenContact(){
	document.getElementById("contactemailfrom").style.border="";
	document.getElementById("contactemailfrom").style.background="";
	document.getElementById("contactemailto").style.border="";
	document.getElementById("contactemailto").style.background="";
	document.getElementById("contactsubject").style.border="";
	document.getElementById("contactsubject").style.background="";
	document.getElementById("contactmessage").style.border="";
	document.getElementById("contactmessage").style.background="";
}


function closeWizard() {
    $('#wizard, #wizardbackground').fadeOut(350);

}

function closeComment() {
    $('#commentbackground, #commentbox').fadeOut(350);
    document.getElementById("commentspace").value = "";

}


function closeContact() {
    $('#contactbackground, #contact').fadeOut(350);
    whitenContact();
    document.getElementById("contactmessage").value="";
}

function removeBios() {
    window.scrollTo(0, 0);	
    bios = document.getElementsByClassName("bio");
    topcontact = document.getElementsByClassName("contactinfotop");
    bottomcontact = document.getElementsByClassName("contactinfobottom");
    if (removebio) {
        document.getElementById("showallbuttonback").innerHTML = '&nbsp;&nbsp;&nbsp;Bio&nbsp;&nbsp;&nbsp;';
        for (var i = 0; i < bios.length; i++) {
            bios[i].style.display = 'none';
            topcontact[i].style.display = 'none';
            bottomcontact[i].style.display = 'block';
        }
        
        setupBlocks();  
        removebio = false;
        
    } else {
        document.getElementById("showallbuttonback").innerHTML = 'No Bio';
        for (var i = 0; i < bios.length; i++) {
            bios[i].style.display = 'block';
            topcontact[i].style.display = 'block';
            bottomcontact[i].style.display = 'none';
         }   
	
	setupBlocks();
	removebio = true;   
        
    }
    placebottombar();
}

function showAll(){
	/*$('.block').each(function (i) {
			$(this).css({
				'opacity': '0', 'filter': 'alpha(opacity=0)'
				});
		});*/
	window.scrollTo(0, 0);	
	if (!hidegroupone) {hideg1(); hidegroupone=true;}
	if (!hidegrouptwo) {hideg2(); hidegrouptwo=true;}
	if (!hidegroupthree) {hideg3(); hidegroupthree=true;}
	setupBlocks();
	/*$('.block').each(function (i) {
			$(this).css({
				'opacity': '1', 'filter': 'alpha(opacity=100)'
				});
	});*/
	placebottombar();
	
	/*setTimeout(function(){ 
	
				}, 600);*/
	
}

function showg1(){
	window.scrollTo(0, 0);	
	if (!hidegroupone) {hideg1(); hidegroupone=true;}
	if (hidegrouptwo) {hideg2(); hidegrouptwo=false;}
	if (hidegroupthree) {hideg3(); hidegroupthree=false;}
	
	 setupBlocks();
	/*$('.block').each(function (i) {
			$(this).css({
				'opacity': '1', 'filter': 'alpha(opacity=100)'
				});
	});*/
	placebottombar();
	
	/*setTimeout(function(){
	
	
				}, 600);*/
	
	
}

function showg2(){
	/*$('.block').each(function (i) {
			$(this).css({
				'opacity': '0', 'filter': 'alpha(opacity=0)'
				});
		});*/
	window.scrollTo(0, 0);	
	
	
	if (hidegroupone) {hideg1(); hidegroupone=false;}
	if (!hidegrouptwo) {hideg2(); hidegrouptwo=true;}
	if (hidegroupthree) {hideg3(); hidegroupthree=false;}
	setupBlocks();
	/*$('.block').each(function (i) {
			$(this).css({
				'opacity': '1', 'filter': 'alpha(opacity=100)'
				});
	});*/
	placebottombar();
	
	/*setTimeout(function(){ 
				}, 600);*/
}


function showg3(){
	/*$('.block').each(function (i) {
			$(this).css({
				'opacity': '0', 'filter': 'alpha(opacity=0)'
				});
		});*/
	window.scrollTo(0, 0);	
	
	if (hidegroupone) {hideg1(); hidegroupone=false;}
	if (hidegrouptwo) {hideg2(); hidegrouptwo=false;}
	if (!hidegroupthree) {hideg3(); hidegroupthree=true;}
	setupBlocks();
	/*$('.block').each(function (i) {
			$(this).css({
				'opacity': '1', 'filter': 'alpha(opacity=100)'
				});
	});*/
	placebottombar();
	
	/*setTimeout(function(){ 
				}, 600);*/
}



function hideg1() {
    classoneelements = document.getElementsByClassName("1");
    if (hidegroupone) {
        document.getElementById("g1buttonback").style.background= 'rgb(71, 71, 71)';
        //hidegroupone = false;
        for (var i = 0; i < classoneelements.length; i++) {
             classoneelements[i].style.display = 'none';
             
             blocke1=classoneelements[i].getElementsByClassName("block")
             blocke1[0].className = "block1";

         }  
    } else {
        document.getElementById("g1buttonback").style.background= '';
        //hidegroupone = true;
        for (var i = 0; i < classoneelements.length; i++) {
             classoneelements[i].style.display = 'block';
             
             blocke1=classoneelements[i].getElementsByClassName("block1")
             blocke1[0].className = "block";
              
         }
    }
    //setupBlocks();
}

function hideg2() {
    classtwoelements = document.getElementsByClassName("2");
    if (hidegrouptwo) {
        document.getElementById("g2buttonback").style.background= 'rgb(71, 71, 71)';
        //hidegrouptwo = false;
        for (var i = 0; i < classtwoelements.length; i++) {
             classtwoelements[i].style.display = 'none';
	     
             blocke2=classtwoelements[i].getElementsByClassName("block")
             blocke2[0].className = "block1";
              
         }  
    } else {
        document.getElementById("g2buttonback").style.background= '';
        //hidegrouptwo = true;
        for (var i = 0; i < classtwoelements.length; i++) {
             classtwoelements[i].style.display = 'block';
	     
	     
             blocke2=classtwoelements[i].getElementsByClassName("block1")
             blocke2[0].className = "block";
         }
    }
    //setupBlocks();
}

function hideg3() {
    classthreeelements = document.getElementsByClassName("3");
    if (hidegroupthree) {
        document.getElementById("g3buttonback").style.background= 'rgb(71, 71, 71)';
        //hidegroupthree = false;
        for (var i = 0; i < classthreeelements.length; i++) {
             classthreeelements[i].style.display = 'none';
             
             blocke3=classthreeelements[i].getElementsByClassName("block")
             blocke3[0].className = "block1";
         }  
    } else {
        document.getElementById("g3buttonback").style.background= '';
        //hidegroupthree = true;
        for (var i = 0; i < classthreeelements.length; i++) {
             classthreeelements[i].style.display = 'block';
             
             
             blocke3=classthreeelements[i].getElementsByClassName("block1")
             blocke3[0].className = "block";
         }
    }
    //setupBlocks();
}

function saveCard(ev) {
	var event = document.getElementById("eventtag").innerHTML;
	var useremail = document.getElementById("useremail").innerHTML;
	var note = document.getElementById("commentspace").value;
	encodednote = encodeURIComponent(note);
	var cardid=document.getElementById("commentcardid").innerHTML;
	var hostdivName=document.getElementById("commentcardname").innerHTML;
	var hostdiv=document.getElementById(hostdivName);
        var savestate=document.getElementById("commentcardsaved").innerHTML;
        var cardRole=document.getElementById("commentcardrole").innerHTML.replace("Role: ", "");
        var nmemberid = document.getElementById("nmemberid").innerHTML;
	var lmemberid = document.getElementById("lmemberid").innerHTML;
        var dataString = 'event1=' + event + '&useremail1=' + useremail + '&note1=' + encodednote + '&cardid1=' + cardid + '&cardrole1=' + cardRole + '&lmemberid1=' + lmemberid + '&nmemberid1=' + nmemberid;
        $("body").css("cursor", "progress");
        $(":button").css("cursor", "progress");
	ev.preventDefault();
        if (useremail == '' ) {
		//alert("Please login to save cards");
		$("body").css("cursor", "default");
		$(":button").css("cursor", "pointer");
		swal("Oops...", "Please login to save cards", "error");
	} else if (savestate=="not saved") {
		// AJAX code to submit form.
		
		$.ajax({
		type: "POST",
		url: "query/savecardquery.php",
		data: dataString,
		cache: false,
		success: function(html) {
		swal({   title: "Saved",    timer: 1000 });
		//alert(dataString);
		//window.location='index.php';
		closeComment();
		document.getElementById("commentcardsaved").innerHTML ="edit"; 
        	document.getElementById("savecardbutton").value="update";
        	(hostdiv.getElementsByClassName("save"))[0].innerHTML ="edit";
        	(hostdiv.getElementsByClassName("save2"))[0].innerHTML ="edit";
        	(hostdiv.getElementsByClassName("commentoncard"))[0].innerHTML =note;
        	$("body").css("cursor", "default");
        	$(":button").css("cursor", "pointer");
			},
		error: function (request, status, error) {
		        //alert(request.responseText);
		$("body").css("cursor", "default");
		$(":button").css("cursor", "pointer");
		    }
		});
		
	}
	else {

		$.ajax({
		type: "POST",
		url: "query/editsavedcardquery.php",
		data: dataString,
		cache: false,
		success: function(html) {
		swal({   title: "Updated",      timer: 1000 });
		//alert(html);
		closeComment();
		(hostdiv.getElementsByClassName("commentoncard"))[0].innerHTML =note;
		$("body").css("cursor", "default");
		$(":button").css("cursor", "pointer");
			},
		error: function (request, status, error) {
		        //alert(request.responseText);
		$("body").css("cursor", "default");
		$(":button").css("cursor", "pointer");
		    }
			
			
		});
		
	}
	//return false;
}



function deleteCard(ev) {
	
	var event = document.getElementById("eventtag").innerHTML;
	var useremail = document.getElementById("useremail").innerHTML;
	var note = document.getElementById("commentspace").value;
	var cardid=document.getElementById("commentcardid").innerHTML;
	var hostdivName=document.getElementById("commentcardname").innerHTML;
	var hostdiv=document.getElementById(hostdivName);
        var savestate=document.getElementById("commentcardsaved").innerHTML;
        var dataString = 'event1=' + event + '&useremail1=' + useremail + '&cardid1=' + cardid;
        $("body").css("cursor", "progress");
        $(":button").css("cursor", "progress");
	ev.preventDefault();
        if (useremail == '' ) {
		//alert("Please login to save cards");
		
	} else {
		// AJAX code to submit form.
		
		$.ajax({
		type: "POST",
		url: "query/deletesavedcardquery.php",
		data: dataString,
		cache: false,
		success: function(html) {
		//alert(html);
		//window.location='index.php';
		if(document.getElementById("displaying").innerHTML != 'savedcards'){swal({   title: "Deleted",     timer: 1000 });}
		closeComment();
		document.getElementById("commentcardsaved").innerHTML ="not saved"; 
        	document.getElementById("savecardbutton").value="save";
        	(hostdiv.getElementsByClassName("save"))[0].innerHTML ="save";
        	(hostdiv.getElementsByClassName("commentoncard"))[0].innerHTML ="";
	        	if(document.getElementById("displaying").innerHTML == 'savedcards'){
			  hostdiv.style.display = 'none';
			  hostdiv.className = "block1";
			  
			  setupBlocks();
			  
	        	}
	        	$("body").css("cursor", "default");
	        	$(":button").css("cursor", "pointer");
			},
		error: function (request, status, error) {
		        //alert(request.responseText);
		        $("body").css("cursor", "default");
		        $(":button").css("cursor", "pointer");
		    }
		});
	}
	
	//return false;
}


function myCards() {
	closeWizard();
	//var event = document.getElementById("event").innerHTML;
	var useremail = document.getElementById("useremail").innerHTML;
	document.getElementById("displaying").innerHTML = 'savedcards';
	var nmemberid = document.getElementById("nmemberid").innerHTML;
	var lmemberid = document.getElementById("lmemberid").innerHTML;
	if(nmemberid==''){nmemberid="Not Available";}
	if(lmemberid==''){lmemberid="Not Available";}

        var dataString = 'useremail=' + useremail + '&lmemberid=' + lmemberid + '&nmemberid=' + nmemberid;
        $("body").css("cursor", "progress");
        $('.topbutton').css("cursor", "progress");
        $('a').css("cursor", "progress");
        
        //alert(useremail=='');
        if (useremail == '' ) {
		//alert("Please login to build your Cardstak");
		$("body").css("cursor", "default");
		$('.topbutton').css("cursor", "pointer");
		$('a').css("cursor", "pointer");
		swal("Oops...", "Please login to save cards", "error");
	} else {
		document.getElementById("mainbody").innerHTML='<div style="width: 100%;position: fixed;top: 300px;padding-left: auto;" ><IMG SRC="images/loader3.gif" class="loader"></div>';
		// AJAX code to submit form.
		$.ajax({
		type: "POST",
		url: "query/mycards.php",
		data: dataString,
		cache: false,
		success: function(html) {
		document.getElementById("mainbody").innerHTML=html;
		setupBlocks();
		
		$('.block').each(function (i) {
			$(this).css({
				'-webkit-transition': 'all .6s ease-out',
				'-moz-transition': 'all .6s ease-out',
				'-o-transition': 'all .6s ease-out',
				'transition': 'all .6s ease-out',  'opacity': '1', 'filter': 'alpha(opacity=100)'
				});
		});
		
		$('.dont_open').click(function (e) {
   		 e.stopPropagation();
		});
	      $(".bio").dotdotdot();
	      placebottombar();	
	      $("body").css("cursor", "default");
	      $('.topbutton').css("cursor", "pointer");
	      $('a').css("cursor", "pointer");
			},
		error: function (request, status, error) {
		        //alert(request.responseText);
		 $("body").css("cursor", "default");
		 $('.topbutton').css("cursor", "pointer");
		 $('a').css("cursor", "pointer");
		    }
		});
		document.getElementById("event").innerHTML=document.getElementById("userstak").innerHTML;
		document.getElementById("addcardbutton").style.display = 'none';
		document.getElementById("backbutton").style.display = '';
		document.getElementById("loginbutton").style.display = 'none';
		document.getElementById("myeventsbutton").style.display = '';
		//document.getElementById("loginbutton").innerHTML = '<span  style="color:black"  onclick="goBack();" id="userstak"> Back </span>';
		document.getElementById("showallbutton").style.display = 'none';
		document.getElementById("g1buttonback").style.display = 'none';
		document.getElementById("g2buttonback").style.display = 'none';
		document.getElementById("g3buttonback").style.display = 'none';
		
		document.getElementById("showallbuttonback").innerHTML = 'No Bio';
		removebio = true;   
		
	}
	return false;
}


function goBack() {
    $("body").css("cursor", "progress");
    $('.topbutton').css("cursor", "progress");
    $(':button').css("cursor", "progress");
    $('a').css("cursor", "progress");
    //document.getElementById("displaying").innerHTML = 'event';
    var event = document.getElementById("eventtag").innerHTML;
    var eventid = document.getElementById("eventid").innerHTML;
    window.location="index.php?event_id="+eventid;
}


function myEvents() {
	$("body").css("cursor", "progress");
        $('.topbutton').css("cursor", "progress");
        $('a').css("cursor", "progress");
	var useremail = document.getElementById("useremail").innerHTML;
	if (useremail == '' ) {
		$("body").css("cursor", "default");
		$('.topbutton').css("cursor", "pointer");
		$('a').css("cursor", "pointer");
		swal("Oops...", "Please login to see your events", "error");
		
	} else {
		var event = document.getElementById("eventtag").innerHTML;
		var eventid = document.getElementById("eventid").innerHTML;
		window.location="index.php?event_id="+eventid+"&page=myevents";
	}		
}

function fillmyEventsCards() {
	document.getElementById("page").innerHTML="myevents";
	document.title="My Events";
	var event = document.getElementById("eventtag").innerHTML;
	var eventid = document.getElementById("eventid").innerHTML;
	var useremail = document.getElementById("useremail").innerHTML;
	document.getElementById("displaying").innerHTML = 'savedevents';
	var nmemberid = document.getElementById("nmemberid").innerHTML;
	var lmemberid = document.getElementById("lmemberid").innerHTML;
	if(nmemberid==''){nmemberid="Not Available";}
	if(lmemberid==''){lmemberid="Not Available";}

        var dataString = 'useremail=' + useremail + '&lmemberid=' + lmemberid + '&nmemberid=' + nmemberid;
        
        //alert(useremail=='');
        if (useremail == '' ) {
		//alert("Please login to create events");
		//sweetAlert("Oops...", "Something went wrong!", "error");
		window.location="index.php?event_id="+eventid;
		$("body").css("cursor", "default");
		$('.topbutton').css("cursor", "pointer");
		$('a').css("cursor", "pointer");
		
	} else {
		// AJAX code to submit form.
		$.ajax({
		type: "POST",
		url: "query/myevents.php",
		data: dataString,
		cache: false,
		success: function(html) {
		document.getElementById("mainbody").innerHTML=html;
		if(eventid==''){document.getElementById("createeventbackbutton").style.display='none';}
		setupBlocks();
		$('.dont_open').click(function (e) {
   		 e.stopPropagation();
		});
		$(".bio").dotdotdot();	
		$("body").css("cursor", "default"); 
		$('.topbutton').css("cursor", "pointer");    
		$('a').css("cursor", "pointer"); 	
			},
		error: function (request, status, error) {
	        //alert(request.responseText);
	        $("body").css("cursor", "default");
	        $('.topbutton').css("cursor", "pointer");
	        $('a').css("cursor", "pointer");
		    }
		});
		
		document.getElementById("event").innerHTML="My Events";
		document.getElementById("addcardbutton").style.display = 'none';
		document.getElementById("backbutton").style.display = '';
		document.getElementById("loginbutton").style.display = '';
		document.getElementById("myeventsbutton").style.display = 'none';
		document.getElementById("showallbutton").style.display = 'none';
		document.getElementById("g1buttonback").style.display = 'none';
		document.getElementById("g2buttonback").style.display = 'none';
		document.getElementById("g3buttonback").style.display = 'none';
		document.getElementById("showallbuttonback").style.display = 'none';
		//document.getElementById("displaybuttonback").style.display = 'none';
		

		
	}
	return false;
}



function deleteEvent(eventid) {
	swal({   title: "Are you sure?",   text: "You will not be able to recover this event",   type: "warning",   showCancelButton: true,   confirmButtonColor: "#DD6B55",   confirmButtonText: "Yes, delete it!",   closeOnConfirm: false }, 
	function(){   swal("Deleted!", "Your event has been deleted.", "success"); 


	var nmemberid = document.getElementById("nmemberid").innerHTML;
	var lmemberid = document.getElementById("lmemberid").innerHTML;
	if(nmemberid==''){nmemberid="Not Available";}
	if(lmemberid==''){lmemberid="Not Available";}

	
	var dataString = 'eventid=' + eventid + '&nmemberid1=' + nmemberid + '&lmemberid1=' + lmemberid  ;
	$("body").css("cursor", "progress");
	//alert(dataString);

	// AJAX code to submit form.
	$.ajax({
	type: "POST",
	url: "query/deleteeventquery.php",
	data: dataString,
	cache: false,
	success: function(event_id) {
	location.reload();
	//document.getElementById("createeventbackbutton").style.display = 'none';
	//document.getElementById("backbutton").style.display = 'none';
	$("body").css("cursor", "default");
		},
	error: function (request, status, error) {
	        //alert(request.responseText);
	        $("body").css("cursor", "default");
	}
	});
	
	return false;
	
	});
}

function validateEmail(email) { 
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}